function signUp(event) {
    if (event) event.preventDefault();
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    console.log(username, password);
    axios.post("http://localhost:3000/signUp", {
        username: username,
        password: password
    }).then((response) => {
        console.log(response.data);
    });
}

function signIn(event) {
    if (event) event.preventDefault();
    let username = document.getElementById("username").value;
    let password = document.getElementById("password").value;
    console.log(username, password);
    axios.post("http://localhost:3000/signIn", {
        username: username,
        password: password
    }).then((response) => {
        console.log(response.data);
        if (response.data=="Invalid username or password") {
            document.getElementById("message").innerHTML="Invalid username or password";
            return;
        }
        else {
            localStorage.setItem("username", username);
            localStorage.setItem("activeToken", response.data);
            document.getElementById("message").innerHTML="Current user is "+username;
        }
    });
    
    
}

function checkLogin() {
    let username = localStorage.getItem("username");
    let activeToken = localStorage.getItem("activeToken");
    if (username && activeToken) {
        document.getElementById("message").innerHTML="Current user is "+username;
    }
}